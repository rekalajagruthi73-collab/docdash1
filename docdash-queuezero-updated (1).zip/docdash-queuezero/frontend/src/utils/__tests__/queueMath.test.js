import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { compareQueuePriority, computeEwmaDuration, computeClientSnapshot } from '../queueMath.js';

describe('queue math', () => {
  it('keeps an active consultation ahead of emergency arrivals', () => {
    const current = { status: 'In Consultation', priority: 'Normal', tokenNumber: 20 };
    const emergency = { status: 'Waiting', priority: 'Emergency', tokenNumber: 21 };
    assert.ok(compareQueuePriority(current, emergency) < 0);
  });

  it('prioritizes emergencies among waiting patients', () => {
    const emergency = { status: 'Waiting', priority: 'Emergency', tokenNumber: 22 };
    const normal = { status: 'Waiting', priority: 'Normal', tokenNumber: 1 };
    assert.ok(compareQueuePriority(emergency, normal) < 0);
  });

  it('ignores invalid consultation samples and bounds the estimate', () => {
    assert.equal(computeEwmaDuration([0, -2, 'bad'], 10), 10);
    assert.equal(computeEwmaDuration([100, 100, 100]), 45);
  });

  it('reports zero wait for the patient currently consulting', () => {
    const snapshot = computeClientSnapshot({
      doctors: [{ id: 'd1', status: 'In Consultation', recentDurations: [10], baseAvgMins: 10 }],
      tokens: [
        { id: 'a', doctorId: 'd1', status: 'In Consultation', tokenNumber: 1 },
        { id: 'b', doctorId: 'd1', status: 'Waiting', tokenNumber: 2 }
      ]
    });
    assert.equal(snapshot.tokens.find((t) => t.id === 'a').estimatedWaitMins, 0);
    assert.equal(snapshot.tokens.find((t) => t.id === 'b').patientsAhead, 1);
  });
});
