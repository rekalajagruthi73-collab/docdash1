/**
 * EWMA consultation-duration estimate.
 * Uses the five most recent valid positive durations; invalid samples are ignored.
 */
export function computeEwmaDuration(durations = [], fallbackMins = 12) {
  const valid = Array.isArray(durations)
    ? durations.slice(-5).map(Number).filter((value) => Number.isFinite(value) && value > 0)
    : [];
  const fallback = Number.isFinite(Number(fallbackMins)) && Number(fallbackMins) > 0
    ? Number(fallbackMins)
    : 12;
  if (valid.length === 0) return Math.max(4, Math.min(45, fallback));

  const alpha = 0.45;
  let ewma = valid[0];
  for (let i = 1; i < valid.length; i += 1) {
    ewma = alpha * valid[i] + (1 - alpha) * ewma;
  }
  return Math.max(4, Math.min(45, Number(ewma.toFixed(1))));
}

export function compareQueuePriority(a, b) {
  // A patient already in consultation stays first; emergencies take priority
  // among everyone who is still waiting.
  const aCurrent = a.status === 'In Consultation';
  const bCurrent = b.status === 'In Consultation';
  if (aCurrent !== bCurrent) return aCurrent ? -1 : 1;
  if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
  if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
  return Number(a.tokenNumber || 0) - Number(b.tokenNumber || 0);
}

export function computeClientSnapshot(raw = {}) {
  const sourceTokens = Array.isArray(raw.tokens) ? raw.tokens : [];
  const doctors = (raw.doctors || []).map((doc) => {
    const dynamicAvgDuration = Number.isFinite(Number(doc.dynamicAvgDuration))
      ? Number(doc.dynamicAvgDuration)
      : computeEwmaDuration(doc.recentDurations, doc.baseAvgMins);
    const activeQueue = sourceTokens
      .filter((t) => t.doctorId === doc.id && !['Completed', 'Absent', 'Holding'].includes(t.status))
      .sort(compareQueuePriority);
    const currentObj = activeQueue.find((t) => t.status === 'In Consultation') || activeQueue[0];
    const nextObj = activeQueue.find((t) => t.status === 'Waiting');
    return {
      ...doc,
      dynamicAvgDuration,
      activeTokenNumber: currentObj ? currentObj.tokenNumber : doc.activeTokenNumber,
      nextTokenNumber: nextObj ? nextObj.tokenNumber : null
    };
  });

  const tokens = sourceTokens.map((tok) => {
    const doc = doctors.find((d) => d.id === tok.doctorId);
    if (!doc) return tok;
    const activeQueue = sourceTokens
      .filter((t) => t.doctorId === doc.id && !['Completed', 'Absent', 'Holding'].includes(t.status))
      .sort(compareQueuePriority);
    const idx = activeQueue.findIndex((t) => t.id === tok.id);
    const patientsAhead = idx > 0 ? idx : 0;
    const delayPenalty = ['On Break', 'Delayed'].includes(doc.status) ? 10 : 0;
    const estimatedWaitMins = ['Completed', 'In Consultation'].includes(tok.status)
      ? 0
      : Math.max(0, Math.round(
          patientsAhead * doc.dynamicAvgDuration +
          Math.max(0, Number(doc.offsetDelayMins) || 0) + delayPenalty
        ));
    return {
      ...tok,
      patientsAhead,
      estimatedWaitMins,
      dynamicAvgDuration: doc.dynamicAvgDuration,
      activeTokenNumber: doc.activeTokenNumber,
      doctorStatus: doc.status,
      shouldAlert: tok.status === 'Waiting' && patientsAhead === 2
    };
  });

  return {
    clinics: raw.clinics || [],
    doctors,
    tokens,
    holdingTokens: raw.holdingTokens || [],
    smsLog: raw.smsLog || []
  };
}
