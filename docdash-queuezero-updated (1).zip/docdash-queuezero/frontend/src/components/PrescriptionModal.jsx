import React from 'react';
import { X, Printer } from 'lucide-react';

export default function PrescriptionModal({ token, onClose }) {
  if (!token || !token.prescription) return null;
  const rx = token.prescription;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 space-y-4">
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              DocDash Digital Prescription
            </span>
            <h3 className="text-lg font-bold text-slate-900">
              Token #{token.tokenNumber} — {token.patientName}
            </h3>
            <p className="text-xs text-slate-500">
              Issued by {rx.doctorName} • {rx.issuedAt}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-sm">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div className="text-xs font-bold uppercase text-slate-500 mb-1">
              Prescribed Medications
            </div>
            <p className="text-slate-800 whitespace-pre-line">{rx.medications}</p>
          </div>

          <div className="bg-teal-50/50 p-3.5 rounded-xl border border-teal-200">
            <div className="text-xs font-bold uppercase text-teal-800 mb-1">
              Consultation Notes & Follow-Up
            </div>
            <p className="text-slate-800 whitespace-pre-line">{rx.notes}</p>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50"
          >
            <Printer className="w-4 h-4" />
            Print / Save PDF
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-teal-600 text-white text-sm font-semibold hover:bg-teal-700"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
