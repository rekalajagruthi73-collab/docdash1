const express = require('express');
const cors = require('cors');
const http = require('http');
const { WebSocketServer } = require('ws');
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

const PORT = process.env.PORT || 4000;
const SEED_PATH = path.join(__dirname, 'data', 'seed.json');
const STATE_PATH = path.join(__dirname, 'data', 'state.json');

// Keep the shipped demo seed immutable; runtime changes are stored separately.
let state = JSON.parse(fs.readFileSync(fs.existsSync(STATE_PATH) ? STATE_PATH : SEED_PATH, 'utf8'));
if (!state.holdingTokens) state.holdingTokens = [];
if (!state.smsLog) state.smsLog = [];

function isValidPhone(value) {
  const digits = String(value || '').replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

function compareQueuePriority(a, b) {
  // Never let a newly injected emergency interrupt a consultation already in progress.
  const aCurrent = a.status === 'In Consultation';
  const bCurrent = b.status === 'In Consultation';
  if (aCurrent !== bCurrent) return aCurrent ? -1 : 1;
  if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
  if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
  return Number(a.tokenNumber || 0) - Number(b.tokenNumber || 0);
}

function saveState() {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

/**
 * Exponentially Weighted Moving Average (EWMA) over the doctor's last 5 consultations.
 * Recent consultations carry higher weight (alpha = 0.45) to react quickly to fluctuations.
 */
function computeEwmaDuration(durations, fallbackMins = 12) {
  const window = Array.isArray(durations)
    ? durations.slice(-5).map(Number).filter((value) => Number.isFinite(value) && value > 0)
    : [];
  if (window.length === 0) return Math.max(4, Math.min(45, Number(fallbackMins) || 12));
  const alpha = 0.45;
  let ewma = window[0];
  for (let i = 1; i < window.length; i++) {
    ewma = alpha * window[i] + (1 - alpha) * ewma;
  }
  return Math.max(4, Math.min(45, Number(ewma.toFixed(1))));
}

/**
 * Rolling Average Queue Estimator:
 * EstimatedWait = (QueuePosition - 1) * DynamicAverageDuration + DoctorOffsetDelay
 */
function enrichDoctor(doc) {
  const dynamicAvgDuration = computeEwmaDuration(doc.recentDurations, doc.baseAvgMins);
  const doctorTokens = state.tokens
    .filter((t) => t.doctorId === doc.id && t.status !== 'Completed' && t.status !== 'Absent')
    .sort(compareQueuePriority);

  const activeTokenObj =
    doctorTokens.find((t) => t.status === 'In Consultation') ||
    doctorTokens.find((t) => t.tokenNumber === doc.activeTokenNumber) ||
    doctorTokens[0] ||
    null;

  const activeTokenNumber = activeTokenObj ? activeTokenObj.tokenNumber : doc.activeTokenNumber;
  const nextTokenObj =
    doctorTokens.find((t) => t.status === 'Waiting') || null;

  return {
    ...doc,
    dynamicAvgDuration,
    activeTokenNumber,
    nextTokenNumber: nextTokenObj ? nextTokenObj.tokenNumber : null,
    waitingCount: doctorTokens.filter((t) => t.status === 'Waiting').length
  };
}

function enrichToken(token) {
  const rawDoc = state.doctors.find((d) => d.id === token.doctorId);
  if (!rawDoc) return token;
  const doc = enrichDoctor(rawDoc);

  const activeQueue = state.tokens
    .filter((t) => t.doctorId === doc.id && t.status !== 'Completed' && t.status !== 'Absent')
    .sort(compareQueuePriority);

  const idx = activeQueue.findIndex((t) => t.id === token.id);
  const queuePosition = idx >= 0 ? idx + 1 : 1;
  const patientsAhead = Math.max(0, queuePosition - 1);

  const statusDelayPenalty = doc.status === 'On Break' ? 10 : doc.status === 'Delayed' ? 10 : 0;
  const estimatedWaitMins =
    token.status === 'Completed' || token.status === 'In Consultation'
      ? 0
      : Math.max(
          0,
          Math.round(patientsAhead * doc.dynamicAvgDuration + (doc.offsetDelayMins || 0) + statusDelayPenalty)
        );

  const shouldAlert = token.status === 'Waiting' && patientsAhead === 2;

  return {
    ...token,
    patientsAhead,
    queuePosition,
    estimatedWaitMins,
    dynamicAvgDuration: doc.dynamicAvgDuration,
    activeTokenNumber: doc.activeTokenNumber,
    doctorStatus: doc.status,
    shouldAlert
  };
}

function getFullSnapshot() {
  return {
    clinics: state.clinics,
    doctors: state.doctors.map(enrichDoctor),
    tokens: state.tokens.map(enrichToken),
    holdingTokens: state.holdingTokens,
    smsLog: state.smsLog.slice(-25),
    updatedAt: new Date().toISOString()
  };
}

function recordTwoAwayAlerts() {
  state.tokens.map(enrichToken).forEach((t) => {
    if (t.shouldAlert) {
      const doc = state.doctors.find((d) => d.id === t.doctorId);
      const clinic = state.clinics.find((c) => c.id === doc?.clinicId);
      const alreadyLogged = state.smsLog.some(
        (entry) => entry.tokenId === t.id && entry.activeTokenNumber === t.activeTokenNumber
      );
      if (!alreadyLogged) {
        state.smsLog.push({
          id: `sms-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          tokenId: t.id,
          tokenNumber: t.tokenNumber,
          activeTokenNumber: t.activeTokenNumber,
          patientName: t.patientName,
          phone: t.phone,
          doctorName: doc?.name || 'Doctor',
          clinicName: clinic?.name || 'Clinic',
          estimatedWaitMins: t.estimatedWaitMins,
          message: `DocDash Alert: Token #${t.tokenNumber} is 2 patients away from ${doc?.name || 'your doctor'} at ${clinic?.name || 'the clinic'}. Est. wait ~${t.estimatedWaitMins} mins — please head to the clinic now.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
      }
    }
  });
}

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

function broadcastState() {
  recordTwoAwayAlerts();
  saveState();
  const payload = JSON.stringify({ type: 'QUEUE_UPDATE', payload: getFullSnapshot() });
  wss.clients.forEach((client) => {
    if (client.readyState === 1) {
      client.send(payload);
    }
  });
}

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'QUEUE_UPDATE', payload: getFullSnapshot() }));
});

// REST Endpoints
app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'DocDash QueueZero API' });
});

app.get('/api/state', (req, res) => {
  res.json(getFullSnapshot());
});

app.get('/api/clinics', (req, res) => {
  res.json(state.clinics);
});

app.get('/api/doctors', (req, res) => {
  const { clinicId, specialty } = req.query;
  let list = state.doctors.map(enrichDoctor);
  if (clinicId && clinicId !== 'all') list = list.filter((d) => d.clinicId === clinicId);
  if (specialty && specialty !== 'all') list = list.filter((d) => d.specialty === specialty);
  res.json(list);
});

// Book a new virtual token
app.post('/api/tokens/book', (req, res) => {
  const { doctorId, patientName, phone, shift, lat, lng } = req.body;
  if (!doctorId || !patientName || !phone) {
    return res.status(400).json({ error: 'doctorId, patientName, and phone are required.' });
  }
  if (typeof patientName !== 'string' || patientName.trim().length < 2 || patientName.trim().length > 80) {
    return res.status(400).json({ error: 'Patient name must be between 2 and 80 characters.' });
  }
  if (!isValidPhone(phone)) {
    return res.status(400).json({ error: 'Enter a valid phone number containing 7 to 15 digits.' });
  }
  const doc = state.doctors.find((d) => d.id === doctorId);
  if (!doc) return res.status(404).json({ error: 'Doctor not found.' });
  if (shift && !state.clinics.find((c) => c.id === doc.clinicId)?.shifts.includes(shift)) {
    return res.status(400).json({ error: 'The selected shift is not available for this clinic.' });
  }
  if ((lat !== undefined || lng !== undefined) &&
      (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180)) {
    return res.status(400).json({ error: 'Latitude or longitude is invalid.' });
  }

  const allDocTokens = [
    ...state.tokens.filter((t) => t.doctorId === doctorId),
    ...state.holdingTokens.filter((t) => t.doctorId === doctorId)
  ];
  const maxToken = allDocTokens.reduce((max, t) => Math.max(max, t.tokenNumber), doc.activeTokenNumber);
  const nextNumber = maxToken + 1;

  // Optional geolocation check-in (< 500m)
  const clinic = state.clinics.find((c) => c.id === doc.clinicId);
  let checkedIn = false;
  if (clinic && typeof lat === 'number' && typeof lng === 'number') {
    const distMeters = haversineMeters(lat, lng, clinic.lat, clinic.lng);
    if (distMeters <= 500) checkedIn = true;
  }

  const newToken = {
    id: `tok-${randomUUID()}`,
    tokenNumber: nextNumber,
    doctorId,
    patientName: patientName.trim(),
    phone: phone.trim(),
    shift: shift || doc.shift,
    status: 'Waiting',
    priority: 'Normal',
    checkedIn,
    prescription: null,
    bookedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  state.tokens.push(newToken);
  broadcastState();
  res.status(201).json({ token: enrichToken(newToken), snapshot: getFullSnapshot() });
});

// Doctor Console: Call Next Patient
app.post('/api/doctors/:doctorId/call-next', (req, res) => {
  const doc = state.doctors.find((d) => d.id === req.params.doctorId);
  if (!doc) return res.status(404).json({ error: 'Doctor not found.' });

  const actualDuration = Number(req.body?.consultationDurationMins);
  if (!Number.isNaN(actualDuration) && actualDuration >= 2 && actualDuration <= 90) {
    doc.recentDurations = [...doc.recentDurations.slice(-4), actualDuration];
  } else {
    // Slightly adapt based on current EWMA with subtle realistic variance
    const currentEwma = computeEwmaDuration(doc.recentDurations, doc.baseAvgMins);
    doc.recentDurations = [...doc.recentDurations.slice(-4), Math.round(currentEwma)];
  }

  // Mark currently consulting token(s) as Completed
  state.tokens.forEach((t) => {
    if (t.doctorId === doc.id && t.status === 'In Consultation') {
      t.status = 'Completed';
      t.completedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
  });

  // Sort waiting tokens (Emergency first, then ascending tokenNumber)
  const waiting = state.tokens
    .filter((t) => t.doctorId === doc.id && t.status === 'Waiting')
    .sort(compareQueuePriority);

  if (waiting.length > 0) {
    waiting[0].status = 'In Consultation';
    doc.activeTokenNumber = waiting[0].tokenNumber;
  } else {
    doc.activeTokenNumber += 1;
  }

  if (doc.status === 'On Break') {
    doc.status = 'In Consultation';
  }

  broadcastState();
  res.json(getFullSnapshot());
});

// Doctor Console: Mark Current Patient Completed
app.post('/api/doctors/:doctorId/complete-current', (req, res) => {
  const doc = state.doctors.find((d) => d.id === req.params.doctorId);
  if (!doc) return res.status(404).json({ error: 'Doctor not found.' });

  const { prescriptionNotes, prescriptionMedications } = req.body || {};
  state.tokens.forEach((t) => {
    if (t.doctorId === doc.id && t.status === 'In Consultation') {
      t.status = 'Completed';
      t.completedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      if (prescriptionNotes || prescriptionMedications) {
        t.prescription = {
          doctorName: doc.name,
          issuedAt: new Date().toLocaleString(),
          notes: prescriptionNotes || 'Routine follow-up advised.',
          medications: prescriptionMedications || 'As directed during consultation.'
        };
      }
    }
  });

  broadcastState();
  res.json(getFullSnapshot());
});

// Doctor Console: Delay +10 mins or update status ('In Consultation', 'On Break', 'Delayed')
app.post('/api/doctors/:doctorId/status', (req, res) => {
  const doc = state.doctors.find((d) => d.id === req.params.doctorId);
  if (!doc) return res.status(404).json({ error: 'Doctor not found.' });

  const { status, addDelayMins } = req.body || {};
  if (addDelayMins !== undefined && (typeof addDelayMins !== 'number' || !Number.isFinite(addDelayMins) || addDelayMins < 0 || addDelayMins > 240)) {
    return res.status(400).json({ error: 'Delay must be a number between 0 and 240 minutes.' });
  }
  if (typeof addDelayMins === 'number') {
    doc.offsetDelayMins = Math.max(0, (doc.offsetDelayMins || 0) + addDelayMins);
    doc.status = 'Delayed';
  }
  if (status && ['In Consultation', 'On Break', 'Delayed'].includes(status)) {
    doc.status = status;
    if (status === 'In Consultation') {
      doc.offsetDelayMins = 0;
    }
  }

  broadcastState();
  res.json(getFullSnapshot());
});

// Handle No-Show: Move token to holding queue and advance immediately
app.post('/api/tokens/:tokenId/absent', (req, res) => {
  const idx = state.tokens.findIndex((t) => t.id === req.params.tokenId);
  if (idx === -1) return res.status(404).json({ error: 'Token not found.' });

  const [absentToken] = state.tokens.splice(idx, 1);
  absentToken.status = 'Holding';
  absentToken.movedToHoldingAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  state.holdingTokens.push(absentToken);

  // If the absent patient was currently marked In Consultation, call next waiting patient
  const doc = state.doctors.find((d) => d.id === absentToken.doctorId);
  if (doc && absentToken.status === 'Holding') {
    const stillConsulting = state.tokens.some(
      (t) => t.doctorId === doc.id && t.status === 'In Consultation'
    );
    if (!stillConsulting) {
      const nextWaiting = state.tokens
        .filter((t) => t.doctorId === doc.id && t.status === 'Waiting')
        .sort(compareQueuePriority)[0];
      if (nextWaiting) {
        nextWaiting.status = 'In Consultation';
        doc.activeTokenNumber = nextWaiting.tokenNumber;
      }
    }
  }

  broadcastState();
  res.json(getFullSnapshot());
});

// Re-queue a patient from holding queue
app.post('/api/holding/:tokenId/requeue', (req, res) => {
  const idx = state.holdingTokens.findIndex((t) => t.id === req.params.tokenId);
  if (idx === -1) return res.status(404).json({ error: 'Token not in holding queue.' });

  const [token] = state.holdingTokens.splice(idx, 1);
  token.status = 'Waiting';
  token.checkedIn = true;
  state.tokens.push(token);

  broadcastState();
  res.json(getFullSnapshot());
});

// Stretch: Emergency Escalation Queue injection
app.post('/api/tokens/emergency', (req, res) => {
  const { doctorId, patientName, phone, triageNote } = req.body || {};
  if (!doctorId || !patientName) {
    return res.status(400).json({ error: 'doctorId and patientName are required.' });
  }
  if (typeof patientName !== 'string' || patientName.trim().length < 2 || patientName.trim().length > 80) {
    return res.status(400).json({ error: 'Patient name must be between 2 and 80 characters.' });
  }
  if (phone && !isValidPhone(phone)) {
    return res.status(400).json({ error: 'Enter a valid phone number containing 7 to 15 digits.' });
  }
  if (typeof patientName !== 'string' || patientName.trim().length < 2 || patientName.trim().length > 80) {
    return res.status(400).json({ error: 'Patient name must be between 2 and 80 characters.' });
  }
  if (typeof triageNote === 'string' && triageNote.length > 500) {
    return res.status(400).json({ error: 'Triage note must be 500 characters or fewer.' });
  }
  const doc = state.doctors.find((d) => d.id === doctorId);
  if (!doc) return res.status(404).json({ error: 'Doctor not found.' });

  const allDocTokens = [
    ...state.tokens.filter((t) => t.doctorId === doctorId),
    ...state.holdingTokens.filter((t) => t.doctorId === doctorId)
  ];
  const maxToken = allDocTokens.reduce((max, t) => Math.max(max, t.tokenNumber), doc.activeTokenNumber);

  const emergencyToken = {
    id: `tok-emg-${randomUUID()}`,
    tokenNumber: maxToken + 1,
    doctorId,
    patientName: patientName.trim(),
    phone: (phone || '+91 98490 00000').trim(),
    shift: doc.shift,
    status: 'Waiting',
    priority: 'Emergency',
    triageNote: triageNote || 'Urgent triage escalation',
    checkedIn: true,
    prescription: null,
    bookedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  state.tokens.push(emergencyToken);
  broadcastState();
  res.status(201).json(getFullSnapshot());
});

// Stretch: Geolocation check-in (< 500m)
function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (v) => (v * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

app.post('/api/tokens/:tokenId/checkin-geo', (req, res) => {
  const token = state.tokens.find((t) => t.id === req.params.tokenId);
  if (!token) return res.status(404).json({ error: 'Token not found.' });

  const doc = state.doctors.find((d) => d.id === token.doctorId);
  const clinic = state.clinics.find((c) => c.id === doc?.clinicId);
  const { lat, lng, simulateNear } = req.body;

  if (!simulateNear && (!clinic || typeof lat !== 'number' || typeof lng !== 'number' ||
      !Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180)) {
    return res.status(400).json({
      error: 'Location coordinates are required for geolocation check-in.',
      checkedIn: false
    });
  }
  const distanceMeters = simulateNear
    ? 180
    : Math.round(haversineMeters(lat, lng, clinic.lat, clinic.lng));

  if (distanceMeters <= 500) {
    token.checkedIn = true;
    broadcastState();
    return res.json({ checkedIn: true, distanceMeters, snapshot: getFullSnapshot() });
  }

  return res.json({ checkedIn: false, distanceMeters, snapshot: getFullSnapshot() });
});

// Stretch: Attach Digital Prescription to completed or active token
app.post('/api/tokens/:tokenId/prescription', (req, res) => {
  const token = state.tokens.find((t) => t.id === req.params.tokenId);
  if (!token) return res.status(404).json({ error: 'Token not found.' });

  const doc = state.doctors.find((d) => d.id === token.doctorId);
  const { notes, medications } = req.body || {};
  if ((notes !== undefined && (typeof notes !== 'string' || notes.length > 2000)) ||
      (medications !== undefined && (typeof medications !== 'string' || medications.length > 2000))) {
    return res.status(400).json({ error: 'Prescription notes and medications must be text up to 2000 characters.' });
  }
  token.prescription = {
    doctorName: doc?.name || 'Attending Physician',
    issuedAt: new Date().toLocaleString(),
    notes: notes || 'Follow-up in 7 days.',
    medications: medications || 'Prescribed regimen attached.'
  };

  broadcastState();
  res.json(getFullSnapshot());
});

// Reset demo dataset
app.post('/api/reset', (req, res) => {
  if (fs.existsSync(STATE_PATH)) fs.unlinkSync(STATE_PATH);
  state = JSON.parse(fs.readFileSync(SEED_PATH, 'utf8'));
  if (!state.holdingTokens) state.holdingTokens = [];
  if (!state.smsLog) state.smsLog = [];
  broadcastState();
  res.json(getFullSnapshot());
});

server.listen(PORT, () => {
  console.log(`DocDash QueueZero server running at http://localhost:${PORT}`);
});
